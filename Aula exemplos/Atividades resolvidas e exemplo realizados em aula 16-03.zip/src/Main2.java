public class Main2 {
    public static void main(String[] args) {
        Exemplo2 ex = new Exemplo2(2,2);
        int quantidade = ex.quantidade();
        double valor= ex.valorTotal();
        System.out.println("Quantidade é:" + quantidade + " Valor:"+ valor);
    }

}
