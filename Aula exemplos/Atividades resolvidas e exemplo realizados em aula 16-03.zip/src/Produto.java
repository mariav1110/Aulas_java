public class Produto {
   //variáveis de classe
    String nome;//vazio ""
    double valor;//0.0
    int quantidade;//0

//Construtores
    Produto(String nome, double valor, int quantidade){
       this.nome=nome;
       this.valor=valor;
       this.quantidade=quantidade;
    }
    //Construtor padrão
    Produto(){
        //se eu não tenho construtor
    }
    /*Produto retornaProduto(){ // objeto
        return new Produto("nome",3,2);
    }*/
    void mostrarProduto(){//método
        //não retorna valor
        System.out.println("Nome do produto:" + nome);
        System.out.println("Valor do produto:" + valor);
        System.out.println("Quantidade do produto:" + quantidade);
        System.out.println("Valor total:" +(valor*quantidade));
    }
    //alteração dos valores de nossa variavel de classe
    void alterarNome(String novoNome){
        nome=novoNome;
    }
    void alterarNome2(String nome){
        this.nome=nome;
    }
    void alterarValor(double valor){
        this.valor=valor;
    }
    void alterarQuantidade(int quantidade){
        this.quantidade=quantidade;
    }

}
