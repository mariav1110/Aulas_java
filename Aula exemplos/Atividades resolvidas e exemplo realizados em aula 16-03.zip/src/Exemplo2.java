public class Exemplo2 {
    //variáveis de classe
    String nome;//vazio ""
    double valor;//0.0
    int quantidade;//0
    Exemplo2(double valor, int quantidade){
      this.valor=valor;
      this.quantidade=quantidade;
    }
    int quantidade(){//método
        // retornar um valor que no caso é um inteiro
     return quantidade ;
    }
    double valorTotal(){
        return quantidade * valor;
    }
}
