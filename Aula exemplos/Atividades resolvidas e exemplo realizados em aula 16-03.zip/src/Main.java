public class Main {
    public static void main(String[] args) {
//criar uma instancia dessa classe.
        Produto mesa = new Produto();//construtor padrão
        mesa.alterarNome("flexform");
        mesa.alterarValor(25.0);
        mesa.alterarQuantidade(5);
        mesa.mostrarProduto();
        Produto computador = new Produto();
        computador.alterarNome("ACEr");
        computador.alterarValor(5000.0);
        computador.alterarQuantidade(5);
        computador.mostrarProduto();
        Produto monitor = new Produto("LG",500,50);
        monitor.mostrarProduto();
        monitor.alterarQuantidade(5);
        monitor.mostrarProduto();
        mesa.alterarNome("abc");
        mesa.mostrarProduto();
        mesa=new Produto("fdsfds",43,43);
        mesa.mostrarProduto();


    }
}