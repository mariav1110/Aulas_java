package Calculadora;

public class TestCalculadoraSimples {

    public static void main(String[] args) {
    int valor1=0;
    int valor2=5;
     CalculadorSimples c = new CalculadorSimples();
     int soma = c.somar(valor1,valor2);
        System.out.println("Valor da soma é:" + soma);
        System.out.println("Valor da subtrair é:" + c.subtrair(1,2));
        System.out.println("Valor da divisão é:" + c.divisao(1,2));
        System.out.println("Valor da multiplicação é:" + c.multiplicacao(1,2));
    }

}
