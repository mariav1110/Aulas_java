package Calculadora;

public class CalculadorSimples {

    int somar(int valor1, int valor2){
      /*  int resultado= valor1+valor2;
       return resultado;*/
        return (valor1+valor2);//retorno um valor - 1 numero inteiro
    }
    int subtrair (int valor1, int valor2){
       return valor1-valor2;
    }

    int multiplicacao(int valor1, int valor2){
         /* int resultado= valor1*valor2;
       return resultado;*/
        return valor1*valor2;
    }

    int divisao (int valor1, int valor2){
        return valor1/valor2;
    }
}
